
<?php $__env->startSection("content"); ?>
<div class="col-12 col-lg-3 g">
   <div class="card component-card_1">
      <div class="card-body">
         <h2 class="card-title"><?php echo e($pnum); ?></h2>
         <p class="card-text">عدد المرضى</p>
      </div>
   </div>
</div>
<div class="col-12 col-lg-3 g">
   <div class="card component-card_1">
      <div class="card-body">
         <h2 class="card-title"><?php echo e($todaydates); ?></h2>
         <p class="card-text">عدد المواعيد اليوم</p>
      </div>
   </div>
</div>
<div class="col-12 col-lg-3 g">
   <div class="card component-card_1">
      <div class="card-body">
         <h2 class="card-title"><?php echo e($todaydatesinfo); ?></h2>
         <p class="card-text">المواعيد المشخصة اليوم</p>
      </div>
   </div>
</div>
<div class="col-12 col-lg-3 g">
   <div class="card component-card_1">
      <div class="card-body">
         <h2 class="card-title"><?php echo e($todaydatesnotinfo); ?></h2>
         <p class="card-text">المواعيد الغير مشخصة اليوم</p>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\clinic\resources\views/home.blade.php ENDPATH**/ ?>