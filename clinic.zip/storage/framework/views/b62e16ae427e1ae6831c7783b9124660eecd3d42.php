
<?php $__env->startSection("content"); ?>

<div class="col-12 g">
   <div class="card card-body table-responsive">
      <table class="table table-hover table-bordered" id="datatable">
         <thead>
            <th>رقم الحجز</th>
            <th>المريض</th>
            <th>الساعة</th>
            <th>المبلغ</th>
            <th>نوع الحجز</th>
            <th>ملاحظات</th>
            <?php if($user->type == 1): ?>
            <th>إضافة تشخيص</th>
            <?php endif; ?>
         </thead>
         <tbody>
            <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><?php echo e($date->date_number); ?></td>
               <td>
                  <?php echo e(App\Http\Controllers\fun::Pname($date->p_id)); ?>

                  <a href="patient/<?php echo e($date->p_id); ?>" class="btn btn-primary fa fa-user" title="عرض الملف الشخصي"></a>
               </td>
               <td><?php echo e($date->time); ?></td>
               <td><?php echo e($date->money); ?></td>
               <td>
                  <?php if($date->type == 0): ?>
                  كشف
                  <?php else: ?>
                  إعادة
                  <?php endif; ?>
               </td>
               <td><?php echo e($date->notes); ?></td>
               <?php if($user->type == 1): ?>
               <td>
                  <?php if($date->info != ""): ?>
                  <button class="btn btn-success" onclick="addInfo('<?php echo e($date->id); ?>')">
                     تم التشخيص
                     <i class="fa fa-check"></i>
                  </button>
                  <?php else: ?>
                  <button class="btn btn-primary" onclick="addInfo('<?php echo e($date->id); ?>')">
                     تشخيص
                     <i class="fa fa-check"></i>
                  </button>
                  <?php endif; ?>
               </td>
               <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\clinic\resources\views/view-today.blade.php ENDPATH**/ ?>