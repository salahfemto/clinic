
<?php $__env->startSection("content"); ?>
<div class="col-12 col-lg-6 g">
   <div class="card card-body">
      <p class='text-muted'>البيانات الأساسية</p>
      <table class="table table-hover">
         <tr>
            <td>الإسم</td>
            <td><?php echo e($patient->name); ?></td>
         </tr>
         <tr>
            <td>رقم الهاتف</td>
            <td><?php echo e($patient->phone); ?></td>
         </tr>
         <tr>
            <td>العنوان</td>
            <td><?php echo e($patient->address); ?></td>
         </tr>
         <tr>
            <td>العمر</td>
            <td><?php echo e($patient->age); ?></td>
         </tr>
         <tr>
            <td>تاريخ التسجيل</td>
            <td><?php echo e($patient->create_date); ?></td>
         </tr>
         <tr>
            <td>ملاحظات</td>
            <td><?php echo e($patient->notes); ?></td>
         </tr>
      </table>
      <p class='text-muted'>التشخيصات والحجوزات</p>
      <div class="table-responsive">
         <table class="table table-hover table-boreded">
            <thead>
               <th>رقم الحجز</th>
               <th>التاريخ</th>
               <th>التشخيص</th>
            </thead>
            <tbody>
               <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                  <td><?php echo e($date->date_number); ?></td>
                  <td><?php echo e($date->date); ?></td>
                  <td><?php echo e($date->info); ?></td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
         </table>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\clinic\resources\views/patient.blade.php ENDPATH**/ ?>